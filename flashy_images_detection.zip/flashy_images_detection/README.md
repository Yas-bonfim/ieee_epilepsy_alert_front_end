# flashy_images_detection
In order to identify videos and animated pictures which can trigger photo sensitive seizures.
